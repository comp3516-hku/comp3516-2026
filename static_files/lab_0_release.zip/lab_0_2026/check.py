# --------------------------------------------------------------------------------
#
# WARNING: This file checks your solution and zips the files for submission.
# Please DO NOT CHANGE ANY PART of this file unless you are absolutely sure of
# the consequences and have consulted with the TA.
#
# --------------------------------------------------------------------------------

from rich import print as rprint
from rich.console import Console
import builtins 
builtins.print = rprint
console = Console()

import argparse
import os
import sys
import subprocess
from datetime import datetime
import zipfile

LAB_ID = 0

def run_pytest_tests():
    """Run pytest with doctest modules and verbose output."""
    console.print("\n[bold cyan]********* Running Tests with Pytest *********[/bold cyan]")
    
    # Run pytest with doctest support and verbose output
    result = subprocess.run(
        ["pytest", "--doctest-modules", "-v", "task_0.py"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # Print colorful output
    console.print(result.stdout)
    if result.returncode != 0:
        console.print("\n[bold red]❌ Some tests failed![/bold red]")
        return False
    else:
        console.print("\n[bold green]✅ All tests passed![/bold green]")
        return True

def zip_files(uid):
    """Zip the submission files."""
    console.print(f"\n[bold cyan]********* Zipping Files *********[/bold cyan]")
    submit_files = ["task_0.py"]
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    zip_file_name = f"{uid}_lab-{LAB_ID}_{timestamp}.zip"

    with zipfile.ZipFile(zip_file_name, "w") as zip_file:
        for file in submit_files:
            if not os.path.exists(file):
                raise FileNotFoundError(f"File {file} not found in {os.getcwd()}")
            console.print(f"Zipping {file}...", end=" ")
            zip_file.write(file)
            console.print("[green]Done.[/green]")
    
    return zip_file_name

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Check the solution and zip the files.')
    parser.add_argument("--uid", type=str, required=True, help="Your University ID. e.g. 1234567")
    args = parser.parse_args()

    # Run tests first
    success = run_pytest_tests()
    
    if not success:
        console.print("\n[bold yellow]⚠️  Fix the test failures before zipping.[/bold yellow]")
        sys.exit(1)

    # Confirm before zipping
    console.print(f"\nYour UID is [bold]{args.uid}[/bold]. Is this correct? (y/n): ", end="")
    if input().lower() != "y":
        console.print("[yellow]Zip operation canceled.[/yellow]")
        sys.exit(0)
        
    # Zip files
    try:
        zip_name = zip_files(args.uid)
        console.print(f"\n[bold green]📦 Successfully created submission package: {zip_name}[/bold green]")
        console.print("[bold green]Please submit this file to Moodle.[/bold green]")
    except Exception as e:
        console.print(f"\n[bold red]❌ Error during zipping: {str(e)}[/bold red]")
        sys.exit(1)